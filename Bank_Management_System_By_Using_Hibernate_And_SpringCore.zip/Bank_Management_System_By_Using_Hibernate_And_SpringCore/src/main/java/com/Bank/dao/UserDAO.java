package com.Bank.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import org.springframework.beans.factory.annotation.Autowired;

public class UserDAO {
	
	@Autowired
	EntityManagerFactory  entityManagerFactory;
	@Autowired
	EntityManager entityManager;
	@Autowired
	EntityTransaction entityTransaction;
	public void insertUserDetails()
	{
		
	}

}
