package com.Bank.config;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.Bank.entity.UserInfo;

@Configuration
@ComponentScan(basePackages = "com.Bank") //Scan all the component class
public class BankConfig {
	
//	@Bean(name = "scannerClass")
	@Bean
	public Scanner scannerClassBean()
	{
		return new Scanner(System.in);
	}
	@Bean
	public EntityManagerFactory  entityManagerFactoryBean()
	{
		return Persistence.createEntityManagerFactory("Bank_Management_System_By_Using_Hibernate_And_SpringCore");
	}
	
	@Bean
	public  EntityManager entityMangerBean(EntityManagerFactory factory)
	{
		return factory.createEntityManager();
	}
	@Bean
	public EntityTransaction entityTransactionBean(EntityManager manager)
	{
		return manager.getTransaction();
	}
	
}
