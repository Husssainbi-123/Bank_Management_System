package com.Bank.service;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;

import com.Bank.entity.UserInfo;

public class UserService {
	@Autowired
	Scanner scanner;
	public void userRegistration()
	{
		System.out.println("Enter user name");
		String name=scanner.next();
		System.out.println("Enter user Mobile Number");
		long mobileNumber=scanner.nextLong();
		System.out.println("Enter user EmailID");
		String emailID=scanner.next();
		System.out.println("Enter user Address");
		String address=scanner.next();
		System.out.println("Enter user Gender");
		String gender=scanner.next();
		System.out.println("Enter user Aadhar Number");
		long aadharNumber=scanner.nextLong();
		System.out.println("Enter user Account Number");
		int AccountNumber=scanner.nextInt();
		System.out.println("Enter user Pin Number");
		int pinNumber=scanner.nextInt();
		System.out.println("Enter user IFSC Code");
		String ifscCode=scanner.next();
		System.out.println("Enter user PAN Number");
		String panNumber=scanner.next();
		System.out.println("Enter user Amount");
		double amount=scanner.nextDouble();
		
		UserInfo userInfo = new UserInfo();
		userInfo.setName(name);
		userInfo.setMobilenumber(mobileNumber);
		userInfo.setEmailid(emailID);
		userInfo.setAddress(address);
		userInfo.setGender(gender);
		userInfo.setAadharnumber(aadharNumber);
		userInfo.setAccountnumber(AccountNumber);
		userInfo.setPin(pinNumber);
		userInfo.setIfsccode(ifscCode);
		userInfo.setPannumber(panNumber);
		userInfo.setAmount(amount);
		
	}

}
